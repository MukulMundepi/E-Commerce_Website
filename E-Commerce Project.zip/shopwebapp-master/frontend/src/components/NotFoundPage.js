import React from "react";

export default class NotFoundPage extends React.Component {
    constructor(props) {
        super(props);
    }

    render () {
        return <h1>Item not found</h1>
    }
}